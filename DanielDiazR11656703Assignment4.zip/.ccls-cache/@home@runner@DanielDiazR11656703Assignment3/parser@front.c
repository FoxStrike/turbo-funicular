/**
 * This the example lexical analyzer code in pages 173 - 177 of the
 * textbook,
 *
 * Sebesta, R. W. (2012). Concepts of Programming Languages. 
 * Pearson, 10th edition.
 *
 */

/* front.c - a lexical analyzer system for simple arithmetic expressions */
#include <stdio.h>
#include <ctype.h>
//#include "parser.c"
#include <string.h>
#include "front.h"
//#include "parser.h"

/* Global Variable */
int nextToken;

/* Local Variables */
 int charClass;
 char lexeme [100];
static char nextChar;
static int lexLen;
static FILE *in_fp;
 char charOut[1][100] = {"test"};

static char keyWords[4][14] = {"while","do","read","print"};

/* Local Function declarations */
static void addChar();
static void getChar();
static void getNonBlank();

/******************************************************/
/* main driver */
int main(int argc, char *argv[]) 
{
    /* Open the input data file and process its contents */
    printf("DanC Analyzer :: R11656703\n");
    if(fopen(argv[1], "r") == NULL)
    {
      printf("File not provided\n");
      exit(2);
    }
    else if ((in_fp = fopen(argv[1], "r")) == NULL) {
      printf ("Error: File not detected\n");
        exit(3);
    } else {
        getChar();
        while (nextToken != EOF) {
          lex();
          prog();
            
            
        } 
    }
    printf("Syntax Validated\n");
    exit(0);
    return 0;
}

/*****************************************************/
/* lookup - a function to lookup operators and parentheses and return the 
 * token */
static int lookup(char ch) {
    switch (ch) {
        case '(':
            addChar();
              strcpy(charOut[0],"LEFT_PAREN");
            getChar();
            nextToken = LEFT_PAREN;
    
            break;
        case ')':
          addChar();
            getChar();
            nextToken = RIGHT_PAREN;
            strcpy(charOut[0],"RIGHT_PAREN");
            break;
        case '+':
          addChar();
            getChar();
            nextToken = ADD_OP;
            strcpy(charOut[0],"ADD_OP");
            break;
        case '-':
          addChar();
            getChar();
            nextToken = SUB_OP;
            strcpy(charOut[0],"SUB_OP");
            break;
        case '*':
          addChar();
            getChar();
            nextToken = MULT_OP;
            strcpy(charOut[0],"MULT_OP");
            break;
        case '/': 
          addChar();
            getChar();
            nextToken = DIV_OP;
            strcpy(charOut[0],"DIV_OP");
            break;
      case '=': 
            addChar();
            getChar();
             if (nextChar == '=') {
                addChar();
                getChar();
        
                nextToken = EQUAL_OP;
                strcpy(charOut[0],"EQUAL_OP");
                break;
              }
              
              
                
            
          
              
                nextToken = ASSIGN_OP;
                strcpy(charOut[0],"ASSIGN_OP");
              
        
            break;
        case '<':
            addChar();
            getChar();
            if (nextChar == '=') {
                addChar();
                getChar();
                nextToken = LEQUAL_OP;
                strcpy(charOut[0],"LEQUAL_OP");
            }
            else if (nextChar == '>') {
                addChar();
                getChar();
                nextToken = NEQUAL_OP;
                strcpy(charOut[0],"NEQUAL_OP");
            }
            else{
                nextToken = LESSER_OP;
              strcpy(charOut[0],"LESSER_OP");
              }
            break;
        case '>':
            addChar();
            getChar();
            if (nextChar == '=') {
                addChar();
                getChar();
                nextToken = GEQUAL_OP;
             strcpy(charOut[0],"GEQUAL_OP");
            }
            else{
                nextToken = GREATER_OP;
              strcpy(charOut[0],"GREATER_OP");
              }
            break;
        case ';':
            addChar();
            getChar();
            nextToken = SEMICOLON;
          strcpy(charOut[0],"SEMICOLON");
            break;
        case '%':
          addChar();
            getChar();
            nextToken = MOD_OP;
         strcpy(charOut[0],"MOD_OP");
            break;
        case '{':
          addChar();
            getChar();
            nextToken = LEFT_CBRACE;
          strcpy(charOut[0],"LEFT_CBRACE");
            break;
        case '}':
          addChar();
            getChar();
            nextToken = RIGHT_CBRACE;
          strcpy(charOut[0],"RIGHT_CBRACE");
            break;
        default:
            addChar();
            getChar();
            nextToken = UNKNOWN_SYM;
            strcpy(charOut[0],"UNKNOWN");
            
    }
    return nextToken;
}


/*****************************************************/
/* addChar - a function to add nextChar to lexeme */
static void addChar() {
    if (lexLen <= 98) {
        lexeme[lexLen++] = nextChar;
        lexeme[lexLen] = 0;
    } else {
        printf("Error - lexeme is too long \n");
    }
}

/*****************************************************/
/* getChar - a function to get the next character of input and determine its 
 * character class */
static void getChar() {
    if ((nextChar = getc(in_fp)) != EOF) {
        if (isalpha(nextChar))
            charClass = LETTER;
        else if (isdigit(nextChar))
            charClass = DIGIT;
        else charClass = UNKNOWN;
    } else {
        charClass = EOF;
    }
}

/*****************************************************/
/* getNonBlank - a function to call getChar until it returns a non-whitespace 
 * character */
static void getNonBlank() {
    while (isspace(nextChar)) getChar();
}

/*****************************************************/
/* lex - a simple lexical analyzer for arithmetic expressions */
int lex() {
    lexLen = 0;
    getNonBlank();
    int flag = 0;
    char ind;


    switch (charClass) {
        /* Parse identifiers */
        case LETTER:
            
            addChar();
            getChar();
            while (charClass == LETTER || charClass == DIGIT) {
                
                addChar();
                getChar();
              
                
            }

     
            for(int x = 0; x < 4; x++)
            {
              if(strcmp(lexeme,keyWords[x]) == 0)
              {
                flag = 1;
                ind = keyWords[x][0];
                //printf("it enters, is a %s\n", lexeme );
              }
              
            }
            if(flag == 1)
            {
              
              switch (ind)
                {
                  case 'w':
                    nextToken = KEY_WHILE;
                    strcpy(charOut[0],"KEY_WHILE");
                    
                    break;
                  
                  case 'd':
                    nextToken = KEY_DO;
                    strcpy(charOut[0],"KEY_DO");
                    break;
                  
                  case 'r':
                    nextToken = KEY_READ;
                    strcpy(charOut[0],"KEY_READ");
                    break;
                  
                  case 'p':
                    nextToken = KEY_PRINT;
                    //addChar();
                    strcpy(charOut[0],"KEY_PRINT");
                    //getChar();
                    break;
                  
                  default:
                    //nextToken = EOF;
                    //strcpy(charOut[0],"EOF");
                    break;
                    
                }
              
            }
            else{
              nextToken = IDENT;
              strcpy(charOut[0],"IDENT");
              //printf("is an ident\n");
              }
            
            break;

        /* Parse integer literals */
        case DIGIT:
            addChar();
            getChar();
            while (charClass == DIGIT) {
                addChar();
                getChar();
            }
            nextToken = INT_LIT;
            strcpy(charOut[0],"INT_LIT");
            break;

        /* Parentheses and operators */
        case UNKNOWN:
            lookup(nextChar);
          //  getChar();
            break;

        /* EOF */
        case EOF:
            nextToken = EOF;
            lexeme[0] = 'E';
            lexeme[1] = 'O';
            lexeme[2] = 'F';
            lexeme[3] = 0;
            //strcpy(charOut[0],"EOF");
            break;
    } /* End of switch */
  if(nextToken != EOF )
    printf( "%s\t     %s\n", lexeme, charOut);
   //printf("Next token is: %d, Next lexeme is %s\n", nextToken, lexeme);
    return nextToken;

} /* End of function lex */

static int errorNoFile()
{
  printf("Cannot detect file\n");
  return 2;
}
 int errorCannotFind()
{
  printf("Cannot find file\n");
  return 3;
}