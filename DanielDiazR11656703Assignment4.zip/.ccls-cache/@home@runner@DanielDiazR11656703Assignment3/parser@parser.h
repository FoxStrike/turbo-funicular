#ifndef PARSER_H
#define PARSER_H

void prog();
void stmt();
void cond();
void expr();
void term();
void factor();
void var();
void number();

extern int nextToken;
extern int charClass;
extern char lexeme [100];
extern char charOut[1][100];
#endif
